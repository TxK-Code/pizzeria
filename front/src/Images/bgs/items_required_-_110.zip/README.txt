This mod changes all trade evolutions to evolve via levelup instead. Due to the game only supporting time-based evolution on held item levelups, please note that the held-item evolutions are time-sensitive. 

To install, move the "romfs" folder to the relevant atmosphere/contents/<titleid> directory. 



Evolution Requirements:

Poliwhirl > Politoed - Level up during Daytime while holding King's Rock
Kadabra > Alakazam - Level 32
Machoke > Machamp - Level 36
Graveler > Golem - Level 36
Slowpoke > Slowking - Level up during Daytime while holding King's Rock
Haunter > Gengar - Level 36
Onix > Steelix - Level up during Nighttime while holding Metal Coat
Rhydon > Rhyperior - Level up during Nighttime while holding Protector
Seadra > Kingdra - Level up during Daytime while holding Dragon Scale
Scyther > Scizor - Level up during Nighttime while holding Metal Coat
Electabuzz > Electivire - Level up during Daytime while holding Electirizer
Magmar > Magmortar - Level up during Nighttime while holding Magmarizer
Porygon > Porygon2 - Level up during Daytime while holding Upgrade
Porygon2 > Porygon-Z - Level up during Daytime while holding Dubious Disc
Feebas > Milotic - Level up during Daytime while holding Prism Scale
Dusclops > Dusknoir - Level up during Nighttime while holding Reaper Cloth
Clamperl > Hunttail - Level up during Nighttime while holding Deep Sea Tooth
Clamperl > Gorebyss  - Level up during Daytime while holding Deep Sea Scale